import React, { useState, useEffect } from 'react';
import InitialSetup from './components/InitialSetup';
import IconSidebar from './components/IconSidebar';
import ImageGrid from './components/ImageGrid';
import PromptInput from './components/PromptInput';
import SettingsPanel from './components/SettingsPanel';
import { createProvider } from './lib/providers/factory';
import { vectorStore } from './lib/rag';
import { generateEmbedding, describeImage } from './lib/gemini';

function App() {
  const [isReady, setIsReady] = useState(false);
  const [provider, setProvider] = useState('stability');
  const [apiKeys, setApiKeys] = useState({
    gemini: '',
    stability: '',
    openai: ''
  });
  const [providerOptions, setProviderOptions] = useState({
    gemini: { model: 'gemini-2.0-flash-exp' },
    stability: { model: 'sd3' },
    openai: { model: 'dall-e-3', size: '1024x1024' }
  });
  const [documents, setDocuments] = useState([]);
  const [generatedImages, setGeneratedImages] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [activeView, setActiveView] = useState('main');

  useEffect(() => {
    // Load settings from localStorage
    const savedProvider = localStorage.getItem('image_provider');
    const savedApiKeys = localStorage.getItem('image_api_keys');
    const savedOptions = localStorage.getItem('image_provider_options');

    if (savedProvider) {
      setProvider(savedProvider);
    }
    if (savedApiKeys) {
      try {
        setApiKeys(JSON.parse(savedApiKeys));
      } catch (e) {
        console.error('Failed to parse saved API keys');
      }
    }
    if (savedOptions) {
      try {
        setProviderOptions(JSON.parse(savedOptions));
      } catch (e) {
        console.error('Failed to parse saved options');
      }
    }

    // Mark as ready after initial load
    setIsReady(true);
  }, []);

  const handleSettingsChange = (newProvider, newApiKeys, newOptions = providerOptions) => {
    setProvider(newProvider);
    setApiKeys(newApiKeys);
    if (newOptions) {
      setProviderOptions(newOptions);
    }

    localStorage.setItem('image_provider', newProvider);
    localStorage.setItem('image_api_keys', JSON.stringify(newApiKeys));
    if (newOptions) {
      localStorage.setItem('image_provider_options', JSON.stringify(newOptions));
    }
  };

  const handleUploadFiles = async (files) => {
    const currentApiKey = apiKeys.gemini; // Use Gemini for RAG processing
    if (!currentApiKey) {
      alert('RAG機能にはGemini API Keyが必要です。設定で追加してください。');
      return;
    }

    for (const file of files) {
      try {
        const isImage = file.type.startsWith('image/');

        if (isImage) {
          const reader = new FileReader();
          reader.onload = async (e) => {
            try {
              const description = await describeImage(e.target.result);
              await vectorStore.addDocument(description, {
                type: 'image',
                filename: file.name,
                source: e.target.result
              });
              setDocuments([...vectorStore.getDocuments()]);
            } catch (error) {
              console.error('Image processing error:', error);
              alert(`画像処理エラー: ${error.message}`);
            }
          };
          reader.readAsDataURL(file);
        } else {
          const text = await file.text();
          await vectorStore.addTextFile(text, file.name);
          setDocuments([...vectorStore.getDocuments()]);
        }
      } catch (error) {
        console.error('Upload error:', error);
        alert(`アップロードエラー: ${error.message}`);
      }
    }
  };

  const handleGenerateImage = async (prompt) => {
    const currentApiKey = apiKeys[provider];
    if (!currentApiKey || currentApiKey.trim() === '') {
      alert(`${provider}のAPI Keyが設定されていません。設定から入力してください。`);
      return;
    }

    setIsGenerating(true);

    try {
      // Search for relevant context
      let enhancedPrompt = prompt;

      if (documents.length > 0) {
        // Use threshold of 0.5 to filter out irrelevant context
        const searchResults = await vectorStore.search(prompt, 3, 0.5);

        if (searchResults.length > 0) {
          const context = searchResults
            .map(r => r.content)
            .join('\n\n');

          // Improve prompt construction for image generation
          enhancedPrompt = `${prompt}\n\n(Reference Context: ${context})`;
          console.log('Using RAG Context:', context);
        }
      }

      // Create provider instance and generate image
      const imageProvider = createProvider(provider, currentApiKey);
      const imageData = await imageProvider.generateImage(
        enhancedPrompt,
        providerOptions[provider]
      );

      // Add to generated images
      setGeneratedImages(prev => [{
        id: Date.now(),
        imageData,
        prompt,
        provider,
        timestamp: new Date()
      }, ...prev]);

    } catch (error) {
      console.error('Generation error:', error);
      alert(error.message || '画像生成エラーが発生しました');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRemoveImage = (id) => {
    setGeneratedImages(prev => prev.filter(img => img.id !== id));
  };

  // Wait for initial load
  if (!isReady) {
    return <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-purple-900/10 flex items-center justify-center text-white">
      <div>読み込み中...</div>
    </div>;
  }

  // Show initial setup if no API key for current provider
  if (!apiKeys[provider] || apiKeys[provider].trim() === '') {
    return <InitialSetup onComplete={handleSettingsChange} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-purple-900/10 text-white">
      {/* Main Container */}
      <div className="flex flex-col md:flex-row gap-0 h-screen w-full max-w-full mx-auto">
        {/* Icon Sidebar */}
        <IconSidebar
          activeView={activeView}
          onHistoryClick={() => setActiveView('history')}
          onGalleryClick={() => setActiveView('gallery')}
          onSettingsClick={() => setShowSettings(true)}
        />

        {/* Main Content */}
        <div className="flex-1 flex flex-col bg-transparent overflow-hidden relative">
          {/* Image Grid */}
          <div className="flex-1 overflow-y-auto min-h-0 pb-32">
            <ImageGrid
              images={generatedImages}
              onUploadFiles={handleUploadFiles}
              onRemoveImage={handleRemoveImage}
            />
          </div>

          {/* Prompt Input */}
          <div className="flex-shrink-0 z-10 w-full">
            <PromptInput
              onSubmit={handleGenerateImage}
              isGenerating={isGenerating}
            />
          </div>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <SettingsPanel
          provider={provider}
          apiKeys={apiKeys}
          providerOptions={providerOptions}
          onSave={handleSettingsChange}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}

export default App;
