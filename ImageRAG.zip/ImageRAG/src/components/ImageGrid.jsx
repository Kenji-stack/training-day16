import React, { useState } from 'react';
import { Upload, X, Sparkles } from 'lucide-react';

export default function ImageGrid({
    images = [],
    onUploadFiles,
    onRemoveImage
}) {
    const [dragActive, setDragActive] = useState(false);

    const handleDrag = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);

        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            onUploadFiles(Array.from(e.dataTransfer.files));
        }
    };

    const handleFileInput = (e) => {
        if (e.target.files && e.target.files[0]) {
            onUploadFiles(Array.from(e.target.files));
        }
    };

    return (
        <div className="flex-1 p-4 md:p-6 overflow-y-auto">
            {/* Upload Area */}
            <div
                className={`mb-6 border-2 border-dashed rounded-2xl p-6 md:p-8 transition-all ${dragActive
                    ? 'border-purple-500 bg-purple-500/10'
                    : 'border-gray-700 bg-gray-800/30'
                    }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
            >
                <label className="flex items-center justify-center gap-3 cursor-pointer">
                    <Upload className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-400 text-sm md:text-base">素材を設定</span>
                    <input
                        type="file"
                        multiple
                        accept=".txt,.md,.png,.jpg,.jpeg"
                        onChange={handleFileInput}
                        className="hidden"
                        aria-label="画像をアップロード"
                    />
                </label>
            </div>

            {/* Image Grid */}
            {images.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {images.map((image, index) => (
                        <div
                            key={image.id || index}
                            className="relative aspect-square bg-gray-800/50 rounded-xl overflow-hidden border border-gray-700/50 hover:border-purple-500/50 transition-all group"
                        >
                            <img
                                src={image.imageData}
                                alt={image.prompt || `Generated ${index + 1}`}
                                className="w-full h-full object-cover"
                            />

                            {/* Overlay */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="absolute bottom-0 left-0 right-0 p-3">
                                    <p className="text-xs text-white line-clamp-2">
                                        {image.prompt || '画像生成'}
                                    </p>
                                    {image.provider && (
                                        <p className="text-xs text-gray-400 mt-1">
                                            {image.provider}
                                        </p>
                                    )}
                                </div>
                            </div>

                            {/* Remove Button */}
                            {onRemoveImage && (
                                <button
                                    onClick={() => onRemoveImage(image.id || index)}
                                    className="absolute top-2 right-2 w-6 h-6 bg-red-500/80 hover:bg-red-500 rounded-full flex items-center justify-center transition-colors shadow-sm"
                                    aria-label="画像を削除"
                                >
                                    <X className="w-4 h-4 text-white" />
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            ) : (
                <div className="flex items-center justify-center h-64 md:h-96">
                    <div className="text-center">
                        <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-purple-500/20 to-pink-600/20 rounded-2xl flex items-center justify-center">
                            <Sparkles className="w-10 h-10 text-purple-400" />
                        </div>
                        <p className="text-gray-400 text-sm md:text-base">画像を生成すると、ここに表示されます</p>
                    </div>
                </div>
            )}
        </div>
    );
}
