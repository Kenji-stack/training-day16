import React, { useState } from 'react';

export default function PromptInput({ onSubmit, isGenerating }) {
    const [prompt, setPrompt] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (prompt.trim() && !isGenerating) {
            onSubmit(prompt);
            setPrompt('');
        }
    };

    return (
        <div className="p-6 bg-white border-b border-gray-200 shadow-md z-50 relative">
            <form onSubmit={handleSubmit} className="max-w-3xl mx-auto flex gap-3">
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="画像生成のプロンプトを入力..."
                    disabled={isGenerating}
                    className="flex-1 px-6 py-3 bg-gray-50 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50 text-black placeholder-gray-500 shadow-inner"
                />
                <button
                    type="submit"
                    disabled={!prompt.trim() || isGenerating}
                    className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-cyan-600 rounded-xl font-medium hover:shadow-lg hover:shadow-cyan-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center text-white min-w-[56px]"
                    aria-label="画像を生成"
                >
                    {isGenerating ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5 animate-spin"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></svg>
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                    )}
                </button>
            </form>
        </div>
    );
}
