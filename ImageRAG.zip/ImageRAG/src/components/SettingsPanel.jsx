import React, { useState } from 'react';
import { X, Info } from 'lucide-react';
import { getAvailableProviders } from '../lib/providers/factory';

export default function SettingsPanel({
    provider,
    apiKeys,
    providerOptions,
    onSave,
    onClose
}) {
    const [localProvider, setLocalProvider] = useState(provider);
    const [localApiKeys, setLocalApiKeys] = useState(apiKeys);
    const [localOptions, setLocalOptions] = useState(providerOptions);

    const providers = getAvailableProviders();
    const currentProviderData = providers.find(p => p.value === localProvider);

    const handleSave = () => {
        onSave(localProvider, localApiKeys, localOptions);
        onClose();
    };

    const updateApiKey = (providerType, value) => {
        setLocalApiKeys(prev => ({ ...prev, [providerType]: value }));
    };

    const updateProviderOption = (providerType, key, value) => {
        setLocalOptions(prev => ({
            ...prev,
            [providerType]: { ...prev[providerType], [key]: value }
        }));
    };

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-gray-800/90 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6 md:p-8 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white">設定</h2>
                    <button
                        onClick={onClose}
                        className="w-8 h-8 rounded-lg bg-gray-700/50 hover:bg-gray-700 flex items-center justify-center transition-all"
                        aria-label="設定を閉じる"
                    >
                        <X className="w-5 h-5 text-gray-400" />
                    </button>
                </div>

                {/* Provider Selection */}
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                            画像生成プロバイダー
                        </label>
                        <select
                            value={localProvider}
                            onChange={(e) => setLocalProvider(e.target.value)}
                            className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                        >
                            {providers.map(p => (
                                <option key={p.value} value={p.value}>
                                    {p.label}
                                </option>
                            ))}
                        </select>
                        {currentProviderData && (
                            <div className="mt-2 flex items-start gap-2 text-xs text-gray-400">
                                <Info className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                <span>{currentProviderData.description}</span>
                            </div>
                        )}
                    </div>

                    {/* API Keys Section */}
                    <div className="space-y-4 pt-4 border-t border-gray-700/50">
                        <h3 className="text-lg font-semibold text-white">API Keys</h3>

                        {/* Stability AI */}
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">
                                Stability AI API Key
                                {localProvider === 'stability' && (
                                    <span className="ml-2 text-xs text-purple-400">(使用中)</span>
                                )}
                            </label>
                            <input
                                type="password"
                                value={localApiKeys.stability || ''}
                                onChange={(e) => updateApiKey('stability', e.target.value)}
                                placeholder="sk-..."
                                className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                            />
                            <a
                                href="https://platform.stability.ai/account/keys"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mt-1 text-xs text-purple-400 hover:text-purple-300 inline-block"
                            >
                                API Keyを取得 →
                            </a>
                        </div>

                        {/* OpenAI */}
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">
                                OpenAI API Key
                                {localProvider === 'openai' && (
                                    <span className="ml-2 text-xs text-purple-400">(使用中)</span>
                                )}
                            </label>
                            <input
                                type="password"
                                value={localApiKeys.openai || ''}
                                onChange={(e) => updateApiKey('openai', e.target.value)}
                                placeholder="sk-..."
                                className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                            />
                            <a
                                href="https://platform.openai.com/api-keys"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mt-1 text-xs text-purple-400 hover:text-purple-300 inline-block"
                            >
                                API Keyを取得 →
                            </a>
                        </div>

                        {/* Gemini */}
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">
                                Gemini API Key
                                {localProvider === 'gemini' && (
                                    <span className="ml-2 text-xs text-purple-400">(使用中)</span>
                                )}
                            </label>
                            <input
                                type="password"
                                value={localApiKeys.gemini || ''}
                                onChange={(e) => updateApiKey('gemini', e.target.value)}
                                placeholder="AIza..."
                                className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                            />
                            <a
                                href="https://aistudio.google.com/app/apikey"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mt-1 text-xs text-purple-400 hover:text-purple-300 inline-block"
                            >
                                API Keyを取得 →
                            </a>
                        </div>
                    </div>

                    {/* Model Options */}
                    {localProvider === 'stability' && (
                        <div className="pt-4 border-t border-gray-700/50">
                            <label className="block text-sm font-medium text-gray-300 mb-2">
                                モデル
                            </label>
                            <select
                                value={localOptions.stability?.model || 'sd3'}
                                onChange={(e) => updateProviderOption('stability', 'model', e.target.value)}
                                className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                            >
                                <option value="sd3">Stable Diffusion 3</option>
                                <option value="sd3-turbo">Stable Diffusion 3 Turbo</option>
                                <option value="core">Stable Diffusion Core</option>
                            </select>
                        </div>
                    )}

                    {localProvider === 'openai' && (
                        <div className="pt-4 border-t border-gray-700/50 space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">
                                    モデル
                                </label>
                                <select
                                    value={localOptions.openai?.model || 'dall-e-3'}
                                    onChange={(e) => updateProviderOption('openai', 'model', e.target.value)}
                                    className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                                >
                                    <option value="dall-e-3">DALL-E 3</option>
                                    <option value="dall-e-2">DALL-E 2</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">
                                    画像サイズ
                                </label>
                                <select
                                    value={localOptions.openai?.size || '1024x1024'}
                                    onChange={(e) => updateProviderOption('openai', 'size', e.target.value)}
                                    className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
                                >
                                    <option value="1024x1024">1024x1024</option>
                                    <option value="1024x1792">1024x1792 (縦長)</option>
                                    <option value="1792x1024">1792x1024 (横長)</option>
                                </select>
                            </div>
                        </div>
                    )}

                    {/* Buttons */}
                    <div className="flex gap-3 pt-6">
                        <button
                            onClick={onClose}
                            className="flex-1 px-4 py-3 bg-gray-700/50 hover:bg-gray-700 rounded-xl font-medium transition-all text-white"
                        >
                            キャンセル
                        </button>
                        <button
                            onClick={handleSave}
                            className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl font-medium hover:shadow-lg hover:shadow-purple-500/50 transition-all text-white"
                        >
                            保存
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
