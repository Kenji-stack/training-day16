import React, { useState, useRef, useEffect } from 'react';
import { Send, Download, Loader2, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

export default function ChatArea({ onGenerateImage, isGenerating }) {
    const [prompt, setPrompt] = useState('');
    const [messages, setMessages] = useState([]);
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!prompt.trim() || isGenerating) return;

        const userMessage = {
            id: Date.now(),
            type: 'user',
            content: prompt
        };

        setMessages(prev => [...prev, userMessage]);
        setPrompt('');

        try {
            const imageData = await onGenerateImage(prompt);

            const aiMessage = {
                id: Date.now() + 1,
                type: 'ai',
                content: prompt,
                imageData
            };

            setMessages(prev => [...prev, aiMessage]);
        } catch (error) {
            const errorMessage = {
                id: Date.now() + 1,
                type: 'error',
                content: error.message
            };
            setMessages(prev => [...prev, errorMessage]);
        }
    };

    const handleDownload = (imageData, prompt) => {
        const link = document.createElement('a');
        link.href = imageData;
        link.download = `imagerag-${Date.now()}.png`;
        link.click();
    };

    return (
        <div className="flex-1 flex flex-col bg-gradient-to-br from-gray-900 via-gray-900 to-purple-900/20">
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages.length === 0 ? (
                    <div className="h-full flex items-center justify-center">
                        <div className="text-center max-w-md">
                            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center">
                                <Sparkles className="w-10 h-10" />
                            </div>
                            <h2 className="text-2xl font-bold mb-3 bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
                                ImageRAGへようこそ
                            </h2>
                            <p className="text-gray-400">
                                素材をアップロードして、RAG拡張された画像生成を体験しましょう
                            </p>
                        </div>
                    </div>
                ) : (
                    messages.map((message) => (
                        <div
                            key={message.id}
                            className={cn(
                                "flex",
                                message.type === 'user' ? "justify-end" : "justify-start"
                            )}
                        >
                            {message.type === 'user' ? (
                                <div className="max-w-2xl px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl rounded-tr-sm">
                                    <p className="text-white">{message.content}</p>
                                </div>
                            ) : message.type === 'error' ? (
                                <div className="max-w-2xl px-6 py-3 bg-red-500/20 border border-red-500/50 rounded-2xl rounded-tl-sm">
                                    <p className="text-red-300">{message.content}</p>
                                </div>
                            ) : (
                                <div className="max-w-3xl space-y-3">
                                    <div className="px-6 py-3 bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-2xl rounded-tl-sm">
                                        <p className="text-gray-300 mb-3">{message.content}</p>
                                        {message.imageData && (
                                            <div className="relative group">
                                                <img
                                                    src={message.imageData}
                                                    alt="Generated"
                                                    className="w-full rounded-lg border border-gray-700/50"
                                                />
                                                <button
                                                    onClick={() => handleDownload(message.imageData, message.content)}
                                                    className="absolute top-3 right-3 p-2 bg-gray-900/80 backdrop-blur-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-800"
                                                >
                                                    <Download className="w-5 h-5" />
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    ))
                )}
                {isGenerating && (
                    <div className="flex justify-start">
                        <div className="px-6 py-4 bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-2xl rounded-tl-sm">
                            <div className="flex items-center gap-3">
                                <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
                                <span className="text-gray-300">画像を生成中...</span>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-6 border-t border-gray-700/50 bg-gray-900/50 backdrop-blur-xl">
                <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
                    <div className="flex gap-3">
                        <input
                            type="text"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="画像生成のプロンプトを入力..."
                            disabled={isGenerating}
                            className="flex-1 px-6 py-4 bg-gray-800/50 border border-gray-700/50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50"
                        />
                        <button
                            type="submit"
                            disabled={!prompt.trim() || isGenerating}
                            className="px-6 py-4 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl font-medium hover:shadow-lg hover:shadow-purple-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            {isGenerating ? (
                                <Loader2 className="w-5 h-5 animate-spin" />
                            ) : (
                                <Send className="w-5 h-5" />
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
