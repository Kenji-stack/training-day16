import React from 'react';
import { Sparkles, Clock, Image as ImageIcon, Settings } from 'lucide-react';
import { cn } from '../lib/utils';

export default function IconSidebar({
    onSettingsClick,
    onHistoryClick,
    onGalleryClick,
    activeView = 'main'
}) {
    return (
        <div className="md:w-16 w-full md:h-auto h-16 bg-gray-900/80 backdrop-blur-xl flex md:flex-col flex-row items-center md:py-6 px-4 md:px-0 gap-4 md:gap-6">
            {/* Logo - Hidden on mobile */}
            <div className="hidden md:flex w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl items-center justify-center shadow-lg shadow-purple-500/30 cursor-pointer">
                <Sparkles className="w-5 h-5 text-white" />
            </div>

            {/* Divider - Hidden on mobile */}
            <div className="hidden md:block w-8 h-px bg-gray-700/50" />

            {/* Navigation */}
            <nav className="flex md:flex-col flex-row gap-4 flex-1 md:flex-none justify-around md:justify-start">
                <button
                    onClick={onHistoryClick}
                    className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center transition-all",
                        activeView === 'history'
                            ? "bg-purple-500/20 text-purple-400"
                            : "text-gray-400 hover:text-white hover:bg-gray-800"
                    )}
                    title="履歴"
                    aria-label="履歴を表示"
                >
                    <Clock className="w-5 h-5" />
                </button>

                <button
                    onClick={onGalleryClick}
                    className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center transition-all",
                        activeView === 'gallery'
                            ? "bg-purple-500/20 text-purple-400"
                            : "text-gray-400 hover:text-white hover:bg-gray-800"
                    )}
                    title="ギャラリー"
                    aria-label="ギャラリーを表示"
                >
                    <ImageIcon className="w-5 h-5" />
                </button>

                <button
                    onClick={onSettingsClick}
                    className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center transition-all",
                        activeView === 'settings'
                            ? "bg-purple-500/20 text-purple-400"
                            : "text-gray-400 hover:text-white hover:bg-gray-800"
                    )}
                    title="設定"
                    aria-label="設定を開く"
                >
                    <Settings className="w-5 h-5" />
                </button>
            </nav>
        </div>
    );
}
