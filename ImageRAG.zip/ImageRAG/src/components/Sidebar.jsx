import React, { useState } from 'react';
import { Settings, Upload, FileText, Image as ImageIcon, Trash2, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Sidebar({
    documents,
    onUpload,
    onClearDocuments,
    apiKey,
    modelName,
    onSettingsChange
}) {
    const [showSettings, setShowSettings] = useState(false);
    const [localApiKey, setLocalApiKey] = useState(apiKey);
    const [localModelName, setLocalModelName] = useState(modelName);

    const handleFileUpload = async (e) => {
        const files = Array.from(e.target.files);
        for (const file of files) {
            await onUpload(file);
        }
        e.target.value = '';
    };

    const handleSaveSettings = () => {
        onSettingsChange(localApiKey, localModelName);
        setShowSettings(false);
    };

    return (
        <div className="w-80 bg-gray-900/50 backdrop-blur-xl border-r border-gray-700/50 flex flex-col">
            {/* Header */}
            <div className="p-6 border-b border-gray-700/50">
                <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/30">
                        <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
                        ImageRAG
                    </h1>
                </div>
                <p className="text-sm text-gray-400">RAG拡張画像生成</p>
            </div>

            {/* Settings Button */}
            <div className="p-4 border-b border-gray-700/50">
                <button
                    onClick={() => setShowSettings(!showSettings)}
                    className={cn(
                        "w-full flex items-center gap-2 px-4 py-3 rounded-lg transition-all",
                        "bg-gray-800/50 hover:bg-gray-800 border border-gray-700/50",
                        showSettings && "bg-purple-500/20 border-purple-500/50"
                    )}
                >
                    <Settings className="w-5 h-5" />
                    <span>設定</span>
                </button>

                {showSettings && (
                    <div className="mt-4 space-y-4 p-4 bg-gray-800/30 rounded-xl border border-gray-700/50">
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">API Key</label>
                            <input
                                type="password"
                                value={localApiKey}
                                onChange={(e) => setLocalApiKey(e.target.value)}
                                placeholder="AIza..."
                                className="w-full px-3 py-2 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">モデル名</label>
                            <input
                                type="text"
                                value={localModelName}
                                onChange={(e) => setLocalModelName(e.target.value)}
                                placeholder="imagen-3.0-generate-001"
                                className="w-full px-3 py-2 bg-gray-900/50 border border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-500"
                            />
                        </div>
                        <button
                            onClick={handleSaveSettings}
                            className="w-full px-4 py-2 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl font-medium hover:shadow-lg hover:shadow-purple-500/50 transition-all"
                        >
                            保存
                        </button>
                    </div>
                )}
            </div>

            {/* Upload Section */}
            <div className="p-4 border-b border-gray-700/50">
                <label className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl transition-all bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:shadow-lg hover:shadow-purple-500/50 cursor-pointer">
                    <Upload className="w-5 h-5" />
                    <span>素材をアップロード</span>
                    <input
                        type="file"
                        multiple
                        accept=".txt,.md,.png,.jpg,.jpeg"
                        onChange={handleFileUpload}
                        className="hidden"
                    />
                </label>
            </div>

            {/* Documents List */}
            <div className="flex-1 overflow-y-auto p-4">
                <div className="flex items-center justify-between mb-3">
                    <h2 className="text-sm font-semibold text-gray-400">
                        素材 ({documents.length})
                    </h2>
                    {documents.length > 0 && (
                        <button
                            onClick={onClearDocuments}
                            className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1"
                        >
                            <Trash2 className="w-3 h-3" />
                            クリア
                        </button>
                    )}
                </div>
                <div className="space-y-2">
                    {documents.map((doc) => (
                        <div
                            key={doc.id}
                            className="p-3 bg-gray-800/30 rounded-lg border border-gray-700/50 hover:border-gray-600/50 transition-all"
                        >
                            <div className="flex items-start gap-2">
                                {doc.metadata.type === 'text' ? (
                                    <FileText className="w-4 h-4 text-blue-400 mt-0.5" />
                                ) : (
                                    <ImageIcon className="w-4 h-4 text-green-400 mt-0.5" />
                                )}
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium truncate">
                                        {doc.metadata.filename}
                                    </p>
                                    {doc.metadata.chunk && (
                                        <p className="text-xs text-gray-500">
                                            チャンク {doc.metadata.chunk}/{doc.metadata.totalChunks}
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
